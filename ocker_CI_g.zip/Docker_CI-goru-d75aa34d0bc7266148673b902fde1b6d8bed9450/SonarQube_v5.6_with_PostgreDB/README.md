SonarQube v5.6 standalone Setup !!

Step 1:- Create Folder structure :- /var/volume/postgres/data
Step 2:- Clone this repository on to a local machine
Step 3:- docker-compose up -d 

SonarQube version no 5.6 exposed on port 9000.
PostgreSQL exposed on port 5432 with Volume /var/volume/postgres/data.

SonarQube uses the PostgreSQL database running in another container.

Some basic commands for docker-compose :-

Start
$ sudo docker-compose -f <compose-file> up -d
Stop
$ sudo docker-compose -f <compose-file> stop
Restart
$ sudo docker-compose -f <compose-file> restart
Status
$ sudo docker-compose -f <compose-file> ps
Logs
$ sudo docker-compose -f <compose-file> logs
Remove
$ sudo docker-compose -f <compose-file> rm

NOTE: On OSX, you should omit the sudo from all your docker-compose commands

