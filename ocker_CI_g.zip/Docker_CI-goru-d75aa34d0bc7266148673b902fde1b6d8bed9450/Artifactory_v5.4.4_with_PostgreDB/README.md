Artifactory OSS v5.4.5 with PostgreSQL standalone Setup !!

Step 1:- Create Folder structure :- /var/volume/artifactory
Step 2:- Create Folder structure :- /var/volume/postgresql
Step 3:- Clone this repository on to a local machine
Step 4:- docker-compose up -d 


Artifactory OSS version no 5.4.5 exposed on port 8081 with Volume /var/volume/artifactory.
PostgreSQL exposed on port 5432 with Volume /var/volume/postgresql.

Artifactory OSS 5.4.5 uses the PostgreSQL database running in another container.

Some basic commands for docker-compose :-

Start
$ sudo docker-compose -f <compose-file> up -d
Stop
$ sudo docker-compose -f <compose-file> stop
Restart
$ sudo docker-compose -f <compose-file> restart
Status
$ sudo docker-compose -f <compose-file> ps
Logs
$ sudo docker-compose -f <compose-file> logs
Remove
$ sudo docker-compose -f <compose-file> rm

NOTE: On OSX, you should omit the sudo from all your docker-compose commands

