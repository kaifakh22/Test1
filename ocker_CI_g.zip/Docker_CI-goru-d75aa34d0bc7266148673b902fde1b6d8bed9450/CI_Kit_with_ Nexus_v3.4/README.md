Jenkins v2.60.1 + Nexus v3.4 +SonarQube v5.6 with PostgreSQL SetUp !!

This GitHub repository contains Dockerfiles for running a set of Continuous Integration Tools with a single command.

Jenkins:-

Jenkins is used for automating the software development process. The Jenkins Docker container 
contains several example Maven build jobs that run Unit tests, execute the static source code 
analysis and deploy the build artifacts to Nexus.

Nexus:-

Nexus is a typical Maven Artifact Repository. The Maven build uses Nexus as a Proxy Repository
for third party libs. After the build the packaged artifacts are deployed to the Nexus Release
Repository.

SonarQube:-

SonarQube is the most widespread Source Code Quality Management Tool. As part of the CI build,
Jenkins triggers a static source code analysis and the results are stored in SonarQube. 
It uses typical code analysis frameworks like FindBugs, Checkstyle, PMD and others.


Step 1:- Create Folder structure :- /var/volume/jenkins
Step 2:- Create Folder structure :- /var/volume/nexus/nexus-data/
Step 3:- Create Folder structure :- /var/volume/postgres/data
Step 4:- Clone this repository on to a local machine
Step 5:- docker-compose up -d 

Jenkins version no 2.60.1 exposed on port 8080 with Volume /var/volume/jenkins.
Nexus version no 3.4 exposed on port 8081 with Volume /var/volume/nexus/nexus-data/.
SonarQube version no 5.6 exposed on port 9000.
PostgreSQL exposed on port 5433 with Volume /var/volume/postgres/data.


Jenkins uses the Nexus and SonarQube running in another container.
SonarQube uses the PostgreSQL database running in another container.

Tool	                      Link	                                     Credentials
Jenkins	      http://${docker-machine ip default}:8080/jenkins/	      no login required
SonarQube	  http://${docker-machine ip default}:9000/	                admin/admin
Nexus	      http://${docker-machine ip default}:8081/nexus	       admin/admin123

Some basic commands for docker-compose :-

Start
$ sudo docker-compose -f <compose-file> up -d
Stop
$ sudo docker-compose -f <compose-file> stop
Restart
$ sudo docker-compose -f <compose-file> restart
Status
$ sudo docker-compose -f <compose-file> ps
Logs
$ sudo docker-compose -f <compose-file> logs
Remove
$ sudo docker-compose -f <compose-file> rm

NOTE: On OSX, you should omit the sudo from all your docker-compose commands
