Sample Spring Boot Web Application with JSP for testing
=====

Building and running
---

    mvn clean spring-boot:run